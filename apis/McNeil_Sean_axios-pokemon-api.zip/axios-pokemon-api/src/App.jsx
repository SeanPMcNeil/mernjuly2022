import './App.css';
import "../node_modules/bootstrap/dist/css/bootstrap.css"
import { Pokemon } from './components/Pokemon';

function App() {
  return (
    <div className="App">
      <Pokemon />
    </div>
  );
}

export default App;
